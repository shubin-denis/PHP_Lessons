-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Сен 06 2020 г., 20:42
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `php_lessons`
--

-- --------------------------------------------------------

--
-- Структура таблицы `images`
--

CREATE TABLE `images` (
  `id` int NOT NULL,
  `address` varchar(2000) NOT NULL,
  `size` int NOT NULL,
  `name` varchar(20) NOT NULL,
  `watch_count` int NOT NULL DEFAULT '0',
  `description` varchar(200) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `images`
--

INSERT INTO `images` (`id`, `address`, `size`, `name`, `watch_count`, `description`, `price`) VALUES
(1, '/images/goods/1.jpg', 10, 'Пальма', 156, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A corporis dolorum eligendi esse illo laboriosam nulla, porro quae temporibus voluptates!', 9990),
(2, '/images/goods/2.jpg', 10, 'Пляж', 24, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A corporis dolorum eligendi esse illo laboriosam nulla, porro quae temporibus voluptates!', 12990),
(3, '/images/goods/3.jpg', 10, 'Вулкан', 8, 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. A corporis dolorum eligendi esse illo laboriosam nulla, porro quae temporibus voluptates!', 29990);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `images`
--
ALTER TABLE `images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
