<h1>
  Каталог товаров
</h1>

<?php
	require_once 'connection.php';
?>

<div>
    <?php foreach ($arrB as $good): ?>
    <div class="shopUnit">
        <img src="<?php echo $good['address']; ?>" />

        <div class="shopUnitName">
            <?php echo $good['name']; ?>
        </div>

        <div class="shopUnitShortDesc">
            <?php echo $good['description']; ?>
        </div>

        <div class="shopUnitPrice">
            Цена: <?php echo $good['price']; ?>
        </div>

        <a href="index.php?page=product&name=<?php echo $good['name']; ?>&id=<?php echo $good['id']; ?>" class="shopUnitMore">
            Подробнее
        </a>
    </div>
    <?php endforeach; ?>
</div>
