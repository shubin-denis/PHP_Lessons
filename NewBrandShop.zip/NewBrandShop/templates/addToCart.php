<?php
echo '<h2>Товар обавлен в корзину</h2><br>
      <a href="?page=shop">Вернуться к покупкам</a>';

require 'func.php';
addCard();