<div id="promo">
        <h1 id="promoText">
            Новый PhoneBrand - это лучший смартфон
        </h1>
    </div>

    <div id="mainTextWrap">
        <div id="mainText">
            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Pariatur, quisquam, ea. Veniam ad saepe ex eum, quas, odio quo autem omnis. Nesciunt, natus! Assumenda expedita minus consectetur ipsum. Quisquam hic magnam nam nesciunt quidem numquam, ab repellat maxime sapiente quia animi perferendis, tenetur aliquid explicabo? Aliquid distinctio a, veniam ea.
        </div>
    </div>