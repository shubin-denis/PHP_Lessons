<?php
function addCard ()
{
    $id = $_GET['id'];
    $name = $_GET['name'];
    $dataLink = mysqli_connect('localhost', 'root', 'root', 'php_lessons');
    $sql = "SELECT id, name, description, price FROM images WHERE name = '$name' ";
    $res = mysqli_query($dataLink, $sql);
    $row = mysqli_fetch_all($res, MYSQLI_ASSOC);

    if (empty($row)) {
        return '';
    }

    if (!empty($_SESSION['goods'][$id])) {
        $_SESSION['goods'][$id]['count']++;
        return '';
    }

    $_SESSION['goods'][$id] = [
        'name' => $row['0']['name'],
        'price' => $row['0']['price'],
        'count' => 1,
    ];

    return '';

}

//function renderCart()
//{
//    if (!empty($_SESSION)) {
//        $html = '<table style="width: 100%;" border="3" style="height: 100% width:200% cellpadding="3" cellspacing="3">
//<tbody>
//<tr>
//<th>Item Name</th>
//<th>Price</th>
//<th> Quantity </th>
//</tr>';
//
//        foreach ($_SESSION['goods'] as $value) {
//            $html .= '
//<tr>
//        <td>' . $goods['goods'][$i]['name'] . '</td>
//        <td>' . $value['price'] . '</td>
//        <td>' . $value['count'] . '</td>
//       </tr>
//</tbody>
//</table>';
//        }
//        return $html;
//    }
//
//    return '<h2>Корзина пуста</h2>';
//
//}
