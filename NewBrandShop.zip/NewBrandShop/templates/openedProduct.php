<?php
require_once 'connection.php';

$name = $_GET['name'];
$c = mysqli_query($dataLink, "SELECT * FROM `images` WHERE name='$name';");
$arrC = mysqli_fetch_all($c, MYSQLI_ASSOC);
mysqli_query($dataLink, "UPDATE images SET count = count+1 WHERE name = '$name';");

?>

<?php foreach ($arrC as $value): ?>
<div style="height: 265px;">
<div id="openedProduct-img">
                <img src="<?php echo $value['address']; ?>">
            </div>
            <div id="openedProduct-content">
                <h1 id="openedProduct-name">
                    <?php echo $value['name']; ?>
                </h1>
                <div id="openedProduct-desc">
                    <?php echo $value['description']; ?>
                </div>
                <div id="openedProduct-price">
                    Цена: <?php echo $value['price']; ?>
                </div>
	            <div style="margin-top: 30px;">
                    <a href="?page=addToCart&name=<?php echo $value['name']; ?>&id=<?php echo $value['id']; ?>">Добавить в корзину</a>
                </div>
            </div>
</div>
<?php endforeach; ?>


<?php

if ($_GET['page'] == 'product') {

    $name = $_POST['name'];
    $goodId = $arrC['0']['id'];
    $userComment = $_POST['comment'];

    $commentsQuery = mysqli_query($dataLink, "SELECT name, text FROM comment WHERE good_id = '$goodId';");
    $allComments = mysqli_fetch_all($commentsQuery, MYSQLI_ASSOC);
    $html = '';

    foreach ($allComments as $value) {

        $html .= '<p> Имя: ' . $value["name"] . '</p>
				<p> Комментарий: ' . $value["text"] . '</p><hr>';

    }



    echo '<div style="margin-bottom: 50px;"> ' . $html . ' </div>';

	echo '<div style="float: left;">
			<form method="post" action="index.php?page=product&name=' . $_GET['name'] . '">
				<input type="text" name="name" placeholder="Ваше имя" style="margin-bottom: 10px;"><br>
    			<textarea name="comment" style="margin: 0px 0px 10px; width: 306px; height: 47px;" placeholder="Комментарий"></textarea><br>
    			<input type="submit">
 			</form>

		</div>
		';



    if (!empty($_POST)) {

        $insertComment = "INSERT INTO `comment` (`name`, `good_id`, `text`) VALUES ('$name', '$goodId', '$userComment');";
        mysqli_query($dataLink, $insertComment);

    }



}


?>
