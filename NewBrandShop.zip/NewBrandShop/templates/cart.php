<div>
	<table style="width: 100%;" border="3" style="height: 100% width:200%" cellpadding="3" cellspacing="3">
		<tbody>
			<tr>
				<th>Название</th>
				<th>Цена</th>
				<th> Количество </th>
				<th> Общая стоимость </th>
			</tr>
<?php foreach ($_SESSION['goods'] as $value): ?>
			<tr>
				<td><?php echo $value['name']; ?></td>
				<td><?php echo $value['price']; ?></td>
				<td><?php echo $value['count']; ?></td>
				<td><?php echo $total = $value['count'] * $value['price']; ?></td>
			</tr>
<?php endforeach; ?>
</tbody>
	</table>
</div>



