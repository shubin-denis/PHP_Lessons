<?php

$dataLink = mysqli_connect('localhost', 'root', 'root', 'php_lessons');
$b = mysqli_query($dataLink, "SELECT * FROM images ORDER BY watch_count DESC;");
$arrB = mysqli_fetch_all($b, MYSQLI_ASSOC);



