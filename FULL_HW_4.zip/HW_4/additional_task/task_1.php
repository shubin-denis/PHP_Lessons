<?php
file_put_contents('log.txt', 'Обновление страницы - ' . date("F j, Y, h:i:s A") . PHP_EOL, FILE_APPEND);
?>