

<?php

$dir = '../../HW_4';
$scan = scandir($dir);
echo "<pre>";
var_dump($scan);
echo "<pre>";

?>