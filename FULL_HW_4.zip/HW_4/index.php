<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Document</title>

</head>
<body>
	<div style="display: flex; justify-content: center;">
		<?php require 'task_1.php';?>

    </div>

    <div style="display: flex; justify-content: center;">
		<?php require 'task_2.php';?>

    </div>
    <div style="display: flex; justify-content: center;">
		<?php require 'task_3.php';?>

    </div>

    <script src="script.js"></script>
</body>
</html>
